// algorithm design project "Binary Search Tree and Priority Queue" for "pedram gray"

#include <iostream>
#include <cstring>
using namespace std;

const int MAX = 100; // max num of nodes 

// arrays for tree storage
int ids[MAX], lefts[MAX], rights[MAX];
char names[MAX][50];
int total = 0, root = -1;

// array for new node creation
int createNode(int id, const char* name)
 {
    
    ids[total] = id;
    // Copy the name
    strcpy(names[total], name);
    lefts[total] = rights[total] = -1;
    return total++;
}

// adding a node to the binary search tree
void addToTree(int& node, int id, const char* name)
 {
    if (node == -1)
     {
        // Create a new node
        node = createNode(id, name);
    }
    // Inserting into the left subtree
    else if (id < ids[node]) 
    {
        addToTree(lefts[node], id, name);
    } 
    // Inserting into the right subtree
    else if (id > ids[node]) 
    {
        addToTree(rights[node], id, name);
    }
}

// searching for a node with a specific id in the tree
int findInTree(int node, int id) 
{
    
    while (node != -1 && ids[node] != id)
     {
       
        node = (id < ids[node]) ? lefts[node] : rights[node];
    }
    return node;
}


// printing the tree
void printTree(int node)
 {
    // In-order traversal
    if (node != -1) 
    {
        
        printTree(lefts[node]);
       
        cout << ids[node] << ": " << names[node] << ", ";
        
        printTree(rights[node]);
    }
}

// finding the minimum node in a subtree
int minNode(int node) 
{
    while (lefts[node] != -1) node = lefts[node];
    return node;
}

// deleting a node from the tree
int deleteFromTree(int node, int id) 
{
    if (node == -1)
     return -1;
    // Found the node to delete
    if (id < ids[node])
     {
        lefts[node] = deleteFromTree(lefts[node], id);
    } 
    
    else if (id > ids[node]) 
    {
        rights[node] = deleteFromTree(rights[node], id);
    } 
   
    else 
    {
        if (lefts[node] == -1) return rights[node];

        if (rights[node] == -1) return lefts[node];

        int next = minNode(rights[node]);
        ids[node] = ids[next];
        strcpy(names[node], names[next]);
        rights[node] = deleteFromTree(rights[node], ids[next]);
    }
    return node;
}

// priority queue arrays
int pids[MAX], pscores[MAX], pcount = 0;

// Helper function to swap elements in the priority queue
void swapAll(int a, int b) 
{
    swap(pids[a], pids[b]);
    swap(pscores[a], pscores[b]);
}

// Push a new element into the priority queue
void pushPQ(int id, int score)
 {
    // Insert the new element
    int i = pcount++;
    pids[i] = id;
    pscores[i] = score;
    // Bubble up the new element
    while (i > 0 && pscores[i] > pscores[(i - 1) / 2])
     {
        
        swapAll(i, (i - 1) / 2);
        i = (i - 1) / 2;
    }
}

// Pop the top element from the priority queue
int popTop()
 {
    if (pcount == 0) return -1;
    int top = pids[0];
    pids[0] = pids[--pcount];
    pscores[0] = pscores[pcount];

    int i = 0;
    // Bubble down the new root
    while (true)
     {
        int l = 2 * i + 1, r = 2 * i + 2, largest = i;
        if (l < pcount && pscores[l] > pscores[largest]) largest = l;
        if (r < pcount && pscores[r] > pscores[largest]) largest = r;
        if (largest == i) break;
        swapAll(i, largest);
        i = largest;
    }
    return top;
}

// Increase the priority of an element in the priority queue
void increasePriority(int id, int newVal) 
{
    for (int i = 0; i < pcount; ++i) 
    {
        if (pids[i] == id && pscores[i] < newVal)
         {
            pscores[i] = newVal;
            while (i > 0 && pscores[i] > pscores[(i - 1) / 2])
            {
                swapAll(i, (i - 1) / 2);
                i = (i - 1) / 2;
            }
            break;
        }
    }
}

// Show the priority queue
void showPQ()
 {
    for (int i = 0; i < pcount; ++i)
        cout << pids[i] << "(" << pscores[i] << ") ";
    cout << endl;
}

int main()
{
    int option, code, score;
    char label[50];
    // Main loop
    while (true)
     {
        cout << "\n1-Add\n2-Find\n3-Delete\n4-Handle\n5-Boost\n6-Tree\n7-Queue\n0-Exit\n> ";
        cin >> option;
        // Handle user options
        if (option == 1)
         {
            cout << "ID: "; cin >> code;
            cout << "Name: "; cin >> label;
            cout << "Priority: "; cin >> score;
            addToTree(root, code, label);
            pushPQ(code, score);
        } else if (option == 2)
         {
            cout << "ID? "; cin >> code;
            int found = findInTree(root, code);
            if (found != -1) cout << "Found: " << names[found] << endl;
            else cout << "Not found.\n";
        } else if (option == 3)
         {
            cout << "Delete ID: "; cin >> code;
            root = deleteFromTree(root, code);
            int tmpID[MAX], tmpS[MAX], j = 0;
            while (pcount > 0) 
            {
                int id = popTop();
                if (id != code)
                 {
                    tmpID[j] = id;
                    tmpS[j++] = pscores[0];
                }
            }
            for (int k = 0; k < j; ++k) pushPQ(tmpID[k], tmpS[k]);
        } else if (option == 4)
         {
            int top = popTop();
            if (top != -1)
             {
                cout << "Handled ID: " << top << endl;
                root = deleteFromTree(root, top);
            } else cout << "Empty queue.\n";
        } else if (option == 5) 
        {
            cout << "Which ID: "; cin >> code;
            cout << "New Priority: "; cin >> score;
            increasePriority(code, score);
        } else if (option == 6) 
        {
            printTree(root);
        } else if (option == 7)
         
        {
            showPQ();
        } else if (option == 0) 
        {
            break;
        } else 
        {
            cout << "Try again.\n";
        }
    }
    return 0;
}