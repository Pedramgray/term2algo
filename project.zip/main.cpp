
#include <iostream>
#include <vector>
#include <iomanip>
using namespace std;

// ----------- BST SECTION -----------
struct RequestBSTNode {
    int id;
    string name;
    RequestBSTNode* left;
    RequestBSTNode* right;
    RequestBSTNode(int i, string n) : id(i), name(n), left(nullptr), right(nullptr) {}
};

class BST {
public:
    RequestBSTNode* root;
    BST() : root(nullptr) {}

    RequestBSTNode* insert(RequestBSTNode* node, int id, string name) {
        if (!node) return new RequestBSTNode(id, name);
        if (id < node->id) node->left = insert(node->left, id, name);
        else if (id > node->id) node->right = insert(node->right, id, name);
        return node;
    }

    void insertRequest(int id, string name) {
        root = insert(root, id, name);
    }

    RequestBSTNode* search(RequestBSTNode* node, int id) {
        if (!node || node->id == id) return node;
        if (id < node->id) return search(node->left, id);
        return search(node->right, id);
    }

    bool searchRequest(int id) {
        return search(root, id) != nullptr;
    }

    RequestBSTNode* findMin(RequestBSTNode* node) {
        while (node->left) node = node->left;
        return node;
    }

    RequestBSTNode* deleteNode(RequestBSTNode* node, int id) {
        if (!node) return node;
        if (id < node->id) node->left = deleteNode(node->left, id);
        else if (id > node->id) node->right = deleteNode(node->right, id);
        else {
            if (!node->left) return node->right;
            else if (!node->right) return node->left;
            RequestBSTNode* temp = findMin(node->right);
            node->id = temp->id;
            node->name = temp->name;
            node->right = deleteNode(node->right, temp->id);
        }
        return node;
    }

    void deleteRequest(int id) {
        root = deleteNode(root, id);
    }

    void printTree(RequestBSTNode* node, int space = 0, int height = 10) {
        if (!node) return;
        space += height;
        printTree(node->right, space);
        cout << endl;
        for (int i = height; i < space; i++) cout << " ";
        cout << node->id << ":" << node->name << "\n";
        printTree(node->left, space);
    }

    void printBST() {
        printTree(root);
    }

    bool isEmptyBST() {
        return root == nullptr;
    }

    int sizeBST(RequestBSTNode* node) {
        if (!node) return 0;
        return 1 + sizeBST(node->left) + sizeBST(node->right);
    }

    int size() {
        return sizeBST(root);
    }
};

// ----------- MAX HEAP SECTION -----------
struct HeapNode {
    int id;
    int priority;
    HeapNode(int i, int p) : id(i), priority(p) {}
};

class MaxHeap {
public:
    vector<HeapNode> heap;

    void maxHeapify(int index) {
        int largest = index;
        int l = 2 * index + 1;
        int r = 2 * index + 2;
        if (l < heap.size() && heap[l].priority > heap[largest].priority)
            largest = l;
        if (r < heap.size() && heap[r].priority > heap[largest].priority)
            largest = r;
        if (largest != index) {
            swap(heap[index], heap[largest]);
            maxHeapify(largest);
        }
    }

    void insertHeap(int id, int priority) {
        HeapNode newNode(id, priority);
        heap.push_back(newNode);
        int i = heap.size() - 1;
        while (i != 0 && heap[(i - 1) / 2].priority < heap[i].priority) {
            swap(heap[i], heap[(i - 1) / 2]);
            i = (i - 1) / 2;
        }
    }

    HeapNode deleteMaxHeap() {
        if (heap.empty()) return HeapNode(-1, -1);
        HeapNode root = heap[0];
        heap[0] = heap.back();
        heap.pop_back();
        maxHeapify(0);
        return root;
    }

    void processHighestPriorityRequest(BST& bst) {
        if (heap.empty()) {
            cout << "Heap is empty!" << endl;
            return;
        }
        HeapNode top = deleteMaxHeap();
        cout << "Processing Request ID: " << top.id << " with Priority: " << top.priority << endl;
        bst.deleteRequest(top.id);
    }

    void printMaxHeap() {
        cout << "Heap Level Order:\n";
        for (int i = 0; i < heap.size(); i++) {
            cout << "(" << heap[i].id << ", " << heap[i].priority << ") ";
        }
        cout << endl;
    }

    void increasePriority(int id, int newPriority) {
        for (int i = 0; i < heap.size(); ++i) {
            if (heap[i].id == id && heap[i].priority < newPriority) {
                heap[i].priority = newPriority;
                while (i != 0 && heap[(i - 1) / 2].priority < heap[i].priority) {
                    swap(heap[i], heap[(i - 1) / 2]);
                    i = (i - 1) / 2;
                }
                break;
            }
        }
    }

    bool isEmptyHeap() {
        return heap.empty();
    }

    int sizeMaxHeap() {
        return heap.size();
    }
};

// ----------- MAIN MENU FUNCTION -----------
int main() {
    BST bst;
    MaxHeap heap;
    int choice;

    do {
        cout << "\n===== Request Management System =====\n";
        cout << "1. Insert Request\n";
        cout << "2. Search Request (BST)\n";
        cout << "3. Delete Request\n";
        cout << "4. Print BST\n";
        cout << "5. Print MaxHeap\n";
        cout << "6. Process Highest Priority Request\n";
        cout << "7. Increase Priority\n";
        cout << "8. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) {
            int id, priority;
            string name;
            cout << "Enter ID: "; cin >> id;
            cout << "Enter Name: "; cin >> name;
            cout << "Enter Priority: "; cin >> priority;
            bst.insertRequest(id, name);
            heap.insertHeap(id, priority);
        }
        else if (choice == 2) {
            int id;
            cout << "Enter ID to search: ";
            cin >> id;
            if (bst.searchRequest(id)) cout << "Request found.\n";
            else cout << "Request not found.\n";
        }
        else if (choice == 3) {
            int id;
            cout << "Enter ID to delete: ";
            cin >> id;
            bst.deleteRequest(id);
            cout << "Note: Request deleted from BST. Manual heap cleanup not implemented.\n";
        }
        else if (choice == 4) {
            cout << "BST Structure:\n";
            bst.printBST();
        }
        else if (choice == 5) {
            heap.printMaxHeap();
        }
        else if (choice == 6) {
            heap.processHighestPriorityRequest(bst);
        }
        else if (choice == 7) {
            int id, newPriority;
            cout << "Enter ID: "; cin >> id;
            cout << "Enter New Priority: "; cin >> newPriority;
            heap.increasePriority(id, newPriority);
        }
        else if (choice == 8) {
            cout << "Exiting...\n";
        }
        else {
            cout << "Invalid choice!\n";
        }

    } while (choice != 8);

    return 0;
}
